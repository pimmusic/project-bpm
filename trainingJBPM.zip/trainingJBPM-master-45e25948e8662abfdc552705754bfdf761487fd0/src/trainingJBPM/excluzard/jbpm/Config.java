package trainingJBPM.excluzard.jbpm;

public class Config {
	public static final String PATN = "http://192.168.99.100:32777/jbpm-console";
	public static final String DEPLOYMENT_ID = "com.excluzard.OrgX:ProjectX:0.0.2";
	public static final String USER = "admin";
	public static final String PASSWORD = "admin";
	
	private String xx ;
	private int i ;
	private Long l ;
	





	@Override
	public String toString() {
		return String.format("Config [xx=%s, i=%s, l=%s]", xx, i, l);
	}






	class ProcessId{
		
		private static final String PROJECT_NAME = "ProjectX";
		public static final String FLOW01 = PROJECT_NAME+".flow01";
		public static final String PARALLEL_FLOW = PROJECT_NAME+".parallelFlow";
		
		
	}
}