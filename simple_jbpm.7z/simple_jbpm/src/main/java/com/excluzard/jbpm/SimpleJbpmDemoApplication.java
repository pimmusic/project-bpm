package com.excluzard.jbpm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SimpleJbpmDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleJbpmDemoApplication.class, args);
	}
}
