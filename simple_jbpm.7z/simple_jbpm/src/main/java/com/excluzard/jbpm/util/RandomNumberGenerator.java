package com.excluzard.jbpm.util;

public class RandomNumberGenerator {

	public static Long generate() {
		return DateUtil.getCurrentDateInIST().getTime();
	}
}
