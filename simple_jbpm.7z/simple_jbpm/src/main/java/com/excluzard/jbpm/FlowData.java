package com.excluzard.jbpm;

import java.io.Serializable;

public class FlowData implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String action;
	private String role;
	private String userName;
	
	public FlowData() {
		super();
	}
	public FlowData(String action, String role, String userName) {
		super();
		this.action = action;
		this.role = role;
		this.userName = userName;
	}
	
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
}
