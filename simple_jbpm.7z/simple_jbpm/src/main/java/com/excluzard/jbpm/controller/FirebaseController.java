package com.excluzard.jbpm.controller;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.excluzard.jbpm.service.FirebaseService;
import com.excluzard.jbpm.service.LosJBPMService;
import com.excluzard.jbpm.service.SimpleJBPMService;

@Controller
@RequestMapping("/user")
public class FirebaseController {

	private static final String ERROR_CODE = "0";
	private static final String SECCESS_CODE = "1";
	private static final String CODE_KEY = "CODE";
	private static final String LOG_KEY = "LOG";
	private static final String ERROR_MSG = "ERROR_MSG";
	private static final String SP = "\n";
	
  @Resource
  private FirebaseService firebaseService;
  
  @Resource
  private SimpleJBPMService jbpmService;
  
  @Resource
  private LosJBPMService losJBPMService;

  /**
   * This method is used to create notification in Jane Doe's Screen.
   */
  @RequestMapping(value = "/create-notification-for-john-doe/", method = RequestMethod.POST)
  @ResponseBody
  public void createNotificationForJaneDoe() {
    firebaseService.pushNotificationtoJaneDoe();
  }

  /**
   * This method is used to create notification in John Doe's Screen.
   */
  @RequestMapping(value = "/create-notification-for-jane-doe/", method = RequestMethod.POST)
  @ResponseBody
  public void createNotificationForJohnDoe() {
    firebaseService.pushNotificationtoJohnDoe();
  }
  
  @RequestMapping(value = "/start-jbpm-flow/", method = RequestMethod.POST)
  public @ResponseBody Map<String, Object> startJbpmFlow() {
	  StringBuilder allLog = new StringBuilder();
	  System.out.println("startJbpmFlow ");
	  allLog.append("startJbpmFlow");
	  allLog.append(SP);
	  String logJbpmService = "";
	  Map<String, Object> resultResp = new HashMap<>();
	  try {
		logJbpmService = losJBPMService.startJBPMFlow();
		resultResp.put(CODE_KEY, SECCESS_CODE);
		allLog.append(logJbpmService);
	} catch (Exception e) {
		resultResp.put(CODE_KEY, ERROR_CODE);
		resultResp.put(ERROR_MSG, e.getMessage());
		allLog.append(e.getMessage());
		allLog.append(SP);
		e.printStackTrace();
		
	}
	  resultResp.put(LOG_KEY, allLog.toString());
	  return resultResp;
  }
  
  @RequestMapping(value = "/next-jbpm-flow/", method = RequestMethod.POST)
  public @ResponseBody Map<String, Object> nextJbpmFlow(@RequestBody Map<String, Object> reqParam) {
	  Map<String, Object> resultResp = new HashMap<>();
	  StringBuilder allLog = new StringBuilder();
	  System.out.println("nextJbpmFlow "+reqParam);
	  allLog.append("nextJbpmFlow "+reqParam);
	  allLog.append(SP);
	  
	  Long processInstanceId = new Long(reqParam.get("processInstanceId")+"");
	  String action = reqParam.get("action")+"";
	  try {
		  String logJbpmService =  losJBPMService.nextJBPMFlow(processInstanceId, action);
		  resultResp.put(CODE_KEY, SECCESS_CODE);
		  allLog.append(logJbpmService);
		  allLog.append(SP);
	  } catch (Exception e) {
		  resultResp.put(CODE_KEY, ERROR_CODE);
		  resultResp.put(ERROR_MSG, e.getMessage());
		  allLog.append(e.getMessage());
		  allLog.append(SP);
		  e.printStackTrace();
	  }
	  resultResp.put(LOG_KEY, allLog.toString());
	  return resultResp;
  }
  
  /*test parallel*/
  @RequestMapping(value = "/start-jbpm-flow-test-paral/", method = RequestMethod.POST)
  public @ResponseBody Map<String, Object> startJbpmtestParalFlow() {
	  StringBuilder allLog = new StringBuilder();
	  System.out.println("startJbpmFlow ");
	  allLog.append("startJbpmFlow");
	  allLog.append(SP);
	  String logJbpmService = "";
	  Map<String, Object> resultResp = new HashMap<>();
	  try {
//		  String procId = "skl-los.TestPala";
		  String procId = "skl-los.LOS_Workflow";
		logJbpmService = losJBPMService.startJBPMFlow(procId);
		resultResp.put(CODE_KEY, SECCESS_CODE);
		allLog.append(logJbpmService);
	} catch (Exception e) {
		resultResp.put(CODE_KEY, ERROR_CODE);
		resultResp.put(ERROR_MSG, e.getMessage());
		allLog.append(e.getMessage());
		allLog.append(SP);
		e.printStackTrace();
		
	}
	  resultResp.put(LOG_KEY, allLog.toString());
	  return resultResp;
  }
  
  @RequestMapping(value = "/next-jbpm-flow-test-paral/", method = RequestMethod.POST)
  public @ResponseBody Map<String, Object> nextJbpmFlowTestParal(@RequestBody Map<String, Object> reqParam) {
	  Map<String, Object> resultResp = new HashMap<>();
	  StringBuilder allLog = new StringBuilder();
	  System.out.println("nextJbpmFlow "+reqParam);
	  allLog.append("nextJbpmFlow "+reqParam);
	  allLog.append(SP);
	  
	  Long processInstanceId = new Long(reqParam.get("processInstanceId")+"");
	  String action = reqParam.get("action")+"";
	  try {
		  String logJbpmService =  losJBPMService.nextJBPMFlow(processInstanceId, action);
		  resultResp.put(CODE_KEY, SECCESS_CODE);
		  allLog.append(logJbpmService);
		  allLog.append(SP);
	  } catch (Exception e) {
		  resultResp.put(CODE_KEY, ERROR_CODE);
		  resultResp.put(ERROR_MSG, e.getMessage());
		  allLog.append(e.getMessage());
		  allLog.append(SP);
		  e.printStackTrace();
	  }
	  resultResp.put(LOG_KEY, allLog.toString());
	  return resultResp;
  }
  @RequestMapping(value = "/next-jbpm-flow-by-task-id/", method = RequestMethod.POST)
  public @ResponseBody Map<String, Object> nextJbpmFlowByTaskId(@RequestBody Map<String, Object> reqParam) {
	  Map<String, Object> resultResp = new HashMap<>();
	  StringBuilder allLog = new StringBuilder();
	  System.out.println("nextJbpmFlow "+reqParam);
	  allLog.append("nextJbpmFlow "+reqParam);
	  allLog.append(SP);
	  
	  Long taskId = new Long(reqParam.get("taskId")+"");
	  String action = reqParam.get("action")+"";
	  try {
		  String logJbpmService =  losJBPMService.nextJBPMFlowByTaskId(taskId, action);
		  resultResp.put(CODE_KEY, SECCESS_CODE);
		  allLog.append(logJbpmService);
		  allLog.append(SP);
	  } catch (Exception e) {
		  resultResp.put(CODE_KEY, ERROR_CODE);
		  resultResp.put(ERROR_MSG, e.getMessage());
		  allLog.append(e.getMessage());
		  allLog.append(SP);
		  e.printStackTrace();
	  }
	  resultResp.put(LOG_KEY, allLog.toString());
	  return resultResp;
  }
  /*------------------*/
  
  
}
