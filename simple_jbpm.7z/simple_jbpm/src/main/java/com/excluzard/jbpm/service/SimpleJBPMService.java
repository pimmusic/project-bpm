package com.excluzard.jbpm.service;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.LongSummaryStatistics;
import java.util.Map;
import java.util.function.ToLongFunction;
import java.util.stream.LongStream;

import org.jgroups.conf.PropertyConverters.LongArray;
import org.kie.api.task.model.Task;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.manager.RuntimeEngine;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.task.TaskService;
import org.kie.remote.client.api.RemoteRuntimeEngineFactory;
import org.springframework.stereotype.Service;

import com.excluzard.jbpm.FlowData;

@Service
public class SimpleJBPMService {

  private static final String FIREBASE_URL = "https://demonotificationspringangular.firebaseio.com";

  private static final String NOTIFICATIONS = "/notifications/";

  private static final String FIRST_USER = "john-doe";

  private static final String SECOND_USER = "jane-doe";

  private static final String SP = "\n";
  
  // กำหนด deployment id กับ path
  // deployment id  =>  {GroupId}:{Artifact ID}:{Version}  =>  demo:simple001:0.0.1
  // ตย. path http://172.20.15.210:8080/jbpm-console/
//  String path = "http://172.20.15.210:8080/jbpm-console/";
//  String path = "http://172.30.31.52:8080/jbpm-console/";
  String path = "http://172.30.31.52:8080/business-central/";
//  String deploymentId = "demo:simple001:0.0.3";
  String deploymentId = "com.gable:los:1.5";
  String username = "admin";
//  String password = "admin";
  String password = "P@ssw0rd";
  
  StringBuilder allLog = new StringBuilder();
  
  public String startJBPMFlow() throws MalformedURLException {
	  KieSession session = getKieSession();
//      String processId = "simple001.register";
      String processId = "skl-los.LOSWorkflow";
      HashMap<String, Object> param = new HashMap<>();
      ProcessInstance processInstance = session.startProcess(processId, param); //<-- START -->
      System.out.println(processInstance);
      genConsoleLog(null, processInstance.getId());
      return allLog.toString();
  }
  
  public String nextJBPMFlow(Long processInstanceId, String action) throws MalformedURLException {
	  TaskService taskService = getTaskService();
	  HashMap<String, Object> param = new HashMap<>();
	  List<Long> jbpmTaskIds = taskService.getTasksByProcessInstanceId(processInstanceId);
	  if(jbpmTaskIds!=null && jbpmTaskIds.size()>0){
//		  Long jbpmTaskId = jbpmTaskIds.get(jbpmTaskIds.size()-1);
		  Long jbpmTaskId = getTaskIdMax(jbpmTaskIds);
		  System.out.println("jbpmTaskId : "+jbpmTaskId);
		  taskService.start(jbpmTaskId , username);
//	        param.put("out_listReq", listFlowData);
		    FlowData outFlowData = new FlowData();
//		    outFlowData.setAction("approve");
		    outFlowData.setAction(action==null?"approve":action);
		    outFlowData.setUserName(username);
	        param.put("out_flowData", outFlowData);
	        taskService.complete(jbpmTaskId, username, param);
	        
	        genConsoleLog(taskService, processInstanceId, jbpmTaskId);
	        
	  }
	  return allLog.toString();
  }
  
  private void genConsoleLog(TaskService taskService, Long processInstanceId){
	  if(taskService==null){
		  taskService = getTaskService();
	  }
	  List<Long> jbpmTaskIds = taskService.getTasksByProcessInstanceId(processInstanceId);
      Long nextJbpmTaskId = getTaskIdMax(jbpmTaskIds);
      System.out.println("new processInstanceId : "+processInstanceId+", Create TaskId :"+ nextJbpmTaskId);
      allLog.append("new processInstanceId : "+processInstanceId+", Create TaskId :"+ nextJbpmTaskId);
      allLog.append(SP);
      Task task = taskService.getTaskById(nextJbpmTaskId);
      System.out.println("curent task Name : "+task.getName());
      allLog.append("curent task Name : "+task.getName());
      allLog.append(SP);
  }
  
  private void genConsoleLog(TaskService taskService, Long processInstanceId, Long oldTaskId){
	  if(taskService==null){
		  taskService = getTaskService();
	  }
//	  StringBuilder allLog = new StringBuilder();
	  List<Long> jbpmTaskIds = taskService.getTasksByProcessInstanceId(processInstanceId);
	  Long nextJbpmTaskId = getTaskIdMax(jbpmTaskIds);
	  if(oldTaskId.equals(nextJbpmTaskId)){
		  System.out.println("complete task id : "+oldTaskId+" in processInstanceId : "+processInstanceId);
		  allLog.append("complete task id : "+oldTaskId+" in processInstanceId : "+processInstanceId);
		  allLog.append(SP);
	  }else{
		  System.out.println(oldTaskId+" to "+ nextJbpmTaskId);
		  allLog.append(oldTaskId+" to "+ nextJbpmTaskId);
		  allLog.append(SP);
		  Task task = taskService.getTaskById(nextJbpmTaskId);
		  System.out.println("curent task Name : "+task.getName());
		  allLog.append("curent task Name : "+task.getName());
		  allLog.append(SP);
	  }
//	  return allLog.toString();
  }
  
  private long getTaskIdMax(List<Long> jbpmTaskIds){
	  /*array version*/
//      LongSummaryStatistics stat = Arrays.stream(jbpmTaskIds).mapToLong((x)-> x.longValue()).summaryStatistics();
	  /*Int Array version*/
//	  int[] ss = {1};
//	  IntSummaryStatistics stats = Arrays.stream(ss).summaryStatistics();
	  
	  LongSummaryStatistics stat = jbpmTaskIds.stream().mapToLong((x)->x.longValue()).summaryStatistics();
	  return stat.getMax();
  }
  private RuntimeEngine setUpRuntimeEngine(){
      // สร้าง runtime egine
      URL url = null;
	try {
		url = new URL(path);
	} catch (MalformedURLException e) {
		e.printStackTrace();
	}
      RuntimeEngine engine = RemoteRuntimeEngineFactory.newRestBuilder()
              .addUrl(url)
              .addUserName(username).addPassword(password)
              .addDeploymentId(deploymentId)
              .build();
      return engine;
  }
  
  private org.kie.api.task.TaskService getTaskService(){
	  return setUpRuntimeEngine().getTaskService();
  }
  
  private KieSession getKieSession(){
	  return setUpRuntimeEngine().getKieSession();
  }
public StringBuilder getAllLog() {
	return allLog;
}
public void setAllLog(StringBuilder allLog) {
	this.allLog = allLog;
}

//  public void pushNotificationtoJaneDoe() {
//    Map<String, Object> data = new LinkedHashMap<>();
//
//    data.put("firstName", "John");
//    data.put("lastName", "Doe");
//    data.put("description", "has sent you friend request!");
//    data.put("read", "false");
//    data.put("imgSrc", "../../img/john.jpg");
//    data.put("date", DateUtil.now().getTime());
//    String url = FIREBASE_URL + NOTIFICATIONS + FIRST_USER;
//    FirebaseUtil.writeToList(url, data);
//  }
//
//  public void pushNotificationtoJohnDoe() {
//    Map<String, Object> data = new LinkedHashMap<>();
//
//    data.put("firstName", "Jane");
//    data.put("lastName", "Doe");
//    data.put("description", "has sent you friend request!");
//    data.put("read", "false");
//    data.put("imgSrc", "../../img/jane.jpg");
//    data.put("date", DateUtil.now().getTime());
//    String url = FIREBASE_URL + NOTIFICATIONS + SECOND_USER;
//    FirebaseUtil.writeToList(url, data);
//  }
}
