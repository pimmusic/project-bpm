angular.module( 'app', [ 'ui.router','ui.bootstrap', 'home', 'firebase', 'simple-start-flow-jbpm' ] ).config( function( $httpProvider, $locationProvider,
  $urlRouterProvider ) {
  $locationProvider.html5Mode( true );
  $urlRouterProvider.otherwise( 'jbpmdemo/home' );
} ).run( function() {
  console.log( "app.js!" );
} );
