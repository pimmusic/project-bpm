angular.module('home', [ 'home.john-doe', 'home.jane-doe', 'home.xx', 'home.los']).config(
		function($stateProvider) {
			$stateProvider.state('home', {
				url : '/jbpmdemo/home',
				templateUrl : '../../js/home/home.tpl',
				controller : 'HomeCtrl'
			});
		}).controller('HomeCtrl', function() {
});
