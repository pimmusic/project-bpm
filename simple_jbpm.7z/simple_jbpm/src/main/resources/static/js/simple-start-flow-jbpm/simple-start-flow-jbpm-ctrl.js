angular.module( 'simple-start-flow-jbpm', [] ).config( function( $stateProvider ) {
  $stateProvider.state( 'simple-start-flow-jbpm', {
    url: '/simple-start-flow-jbpm',
    templateUrl: '../../js/simple-start-flow-jbpm/simple-start-flow-jbpm.tpl',
    controller: 'SimpleStartFlowJbpmCtrl'
  } );
} ).controller( 'SimpleStartFlowJbpmCtrl', function( $scope, JohnDoeUserService, $firebase ) {
	
} );
