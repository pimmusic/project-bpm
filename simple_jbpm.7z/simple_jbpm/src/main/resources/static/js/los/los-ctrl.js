angular.module( 'home.los', [] ).config( function( $stateProvider ) {
  $stateProvider.state( 'home.los', {
    url: '/los',
    templateUrl: '../../js/los/los.tpl',
    controller: 'LosCtrl'
  } );
} ).controller( 'LosCtrl', function( $scope, LosService, $firebase ) {
	$scope.action = "approve";
	  $scope.startJBPMFlow = function() {
		    console.log( "startJBPMFlow" );
		    LosService.startJBPMFlow().success( function( response ) {
		      console.log( "startJBPMFlow Service success." );
		      console.log( "response",response);
		      $scope.log=response.LOG;
		    } ).error( function( response ) {
		      console.log( "Something bad happened!" );
		      console.log( "response",response);
		      $scope.log=response.LOG;
		    } );
	  };
	  $scope.nextJBPMFlow = function() {
		  console.log( "nextJBPMFlow " + $scope.processInstanceId);
		  LosService.nextJBPMFlow($scope.processInstanceId, $scope.action).success( function( response ) {
			  console.log( "nextJBPMFlow Service success." );
			  console.log( "response",response);
			  $scope.log=response.LOG;
		  } ).error( function( response ) {
			  console.log( "Something bad happened!" );
			  console.log( "response",response);
			  $scope.log=response.LOG;
		  } );
	  };
	  $scope.nextJBPMFlowByTaskId = function() {
		  console.log( "nextJBPMFlowByTaskId " + $scope.taskId);
		  LosService.nextJBPMFlowByTaskId($scope.taskId, $scope.action).success( function( response ) {
			  console.log( "nextJBPMFlow Service success." );
			  console.log( "response",response);
			  $scope.log=response.LOG;
		  } ).error( function( response ) {
			  console.log( "Something bad happened!" );
			  console.log( "response",response);
			  $scope.log=response.LOG;
		  } );
	  };
} );
