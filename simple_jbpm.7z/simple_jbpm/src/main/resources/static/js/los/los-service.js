angular.module( 'app' ).factory( 'LosService', function( $http ) {
  return {
	  	startJBPMFlow: function() {
	  	console.log("call startJBPMFlow service")
//	  	return $http.post( 'user/start-jbpm-flow/' );
	  	return $http.post( 'user/start-jbpm-flow-test-paral/' );
    },
    	nextJBPMFlow: function(processInstanceId, action) {
    		console.log("call nextJBPMFlow service")
//    	return $http.post( 'user/next-jbpm-flow/' , {"processInstanceId":processInstanceId, "action":action});
    		return $http.post( 'user/next-jbpm-flow-test-paral/' , {"processInstanceId":processInstanceId, "action":action});
    },
    	nextJBPMFlowByTaskId: function(taskId, action) {
    	console.log("call nextJBPMFlowByTaskId service")
//    	return $http.post( 'user/next-jbpm-flow/' , {"processInstanceId":processInstanceId, "action":action});
    	return $http.post( 'user/next-jbpm-flow-by-task-id/' , {"taskId":taskId, "action":action});
    },
  };
} );
