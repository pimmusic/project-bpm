angular.module( 'app' ).factory( 'XxService', function( $http ) {
  return {
	  	startJBPMFlow: function() {
	  	console.log("call startJBPMFlow service")
	  	return $http.post( 'user/start-jbpm-flow/' );
    },
    	nextJBPMFlow: function(processInstanceId, action) {
    		console.log("call nextJBPMFlow service")
    	return $http.post( 'user/next-jbpm-flow/' , {"processInstanceId":processInstanceId, "action":action});
    },
  };
} );
