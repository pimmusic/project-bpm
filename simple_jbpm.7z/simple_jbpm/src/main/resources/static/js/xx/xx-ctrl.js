angular.module( 'home.xx', [] ).config( function( $stateProvider ) {
  $stateProvider.state( 'home.xx', {
    url: '/xx',
    templateUrl: '../../js/xx/xx.tpl',
    controller: 'XxCtrl'
  } );
} ).controller( 'XxCtrl', function( $scope, XxService, $firebase ) {
	$scope.action = "approve";
	  $scope.startJBPMFlow = function() {
		    console.log( "startJBPMFlow" );
		    XxService.startJBPMFlow().success( function( response ) {
		      console.log( "startJBPMFlow Service success." );
		      console.log( "response",response);
		      $scope.log=response.LOG;
		    } ).error( function( response ) {
		      console.log( "Something bad happened!" );
		      console.log( "response",response);
		      $scope.log=response.LOG;
		    } );
	  };
	  $scope.nextJBPMFlow = function() {
		  console.log( "nextJBPMFlow " + $scope.processInstanceId);
		  XxService.nextJBPMFlow($scope.processInstanceId, $scope.action).success( function( response ) {
			  console.log( "nextJBPMFlow Service success." );
			  console.log( "response",response);
			  $scope.log=response.LOG;
		  } ).error( function( response ) {
			  console.log( "Something bad happened!" );
			  console.log( "response",response);
			  $scope.log=response.LOG;
		  } );
	  };
} );
